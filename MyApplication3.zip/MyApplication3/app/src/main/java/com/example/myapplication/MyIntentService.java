package com.example.myapplication;

import android.app.IntentService;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Binder;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.Timer;

/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p>
 * <p>
 * TODO: Customize class - update intent actions, extra parameters and static
 * helper methods.
 */
public class MyIntentService extends Service {

    private boolean isRunning = false;
    private long startTime = 0;
    private long timeInMilliseconds = 0;
    private long timeSwapBuff = 0;
    private long updatedTime = 0;
    private final IBinder mBinder = new LocalBinder();
    private Message timeMsg;

    private Looper serviceLooper;

    /*public Runnable updateTimer = new Runnable() {
        public void run() {
            timeInMilliseconds = SystemClock.uptimeMillis() - startTime;
            updatedTime = timeSwapBuff + timeInMilliseconds;
            Log.d("Czas:", String.valueOf(updatedTime));

            timeMsg = new Message();
            timeMsg.obj = updatedTime;
            Stop.sHandler.sendMessage(timeMsg);

            Stop.sHandler.postDelayed(this, 0);
        }
    };

    public void startStop(){

        if (isRunning) {
            timeSwapBuff += timeInMilliseconds;
            Stop.sHandler.removeCallbacks(updateTimer);
            isRunning = false;
        } else {
            startTime = SystemClock.uptimeMillis();
            Stop.sHandler.postDelayed(updateTimer, 0);
            isRunning = true;
        }
    }

    public void reset(){

        Stop.sHandler.removeCallbacks(updateTimer);
        isRunning=false;
        startTime = 0L;
        timeInMilliseconds = 0L;
        timeSwapBuff = 0L;
        updatedTime = 0L;

        timeMsg = new Message();
        timeMsg.obj = updatedTime;
        Stop.sHandler.sendMessage(timeMsg);

    }*/

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private ServiceHandler serviceHandler;

    // Handler that receives messages from the thread
    private final class ServiceHandler extends Handler {
        public ServiceHandler(Looper looper) {
            super(looper);
        }
        @Override
        public void handleMessage(Message msg) {
            // Normally we would do some work here, like download a file.
            // For our sample, we just sleep for 5 seconds.
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                // Restore interrupt status.
                Thread.currentThread().interrupt();
            }
            // Stop the service using the startId, so that we don't stop
            // the service in the middle of handling another job
            stopSelf(msg.arg1);
        }
    }

    @Nullable
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        System.out.println(" I am here in the top");

        CountDownTimer countDownTimer = new CountDownTimer(240000000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

                Intent intent = new Intent(getApplicationContext(), Stop.class);

                intent.putExtra("time", "" + millisUntilFinished);

                System.out.println("I am counting");

                long currentTime = millisUntilFinished;

                int secs = (int) (currentTime / 1000);
                int mins = secs / 60;
                secs = secs % 60;
                int millis = (int) (currentTime % 1000);

                getApplicationContext().sendBroadcast(intent);

            }

            @Override
            public void onFinish() {

                Toast.makeText(getApplicationContext(), "I am stop", Toast.LENGTH_LONG).show();

            }
        };

        countDownTimer.start();

        return START_STICKY;
    }

    public class LocalBinder extends Binder {
        public MyIntentService getService(){
            return MyIntentService.this;
        }
    }

}