package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button stopwatch, backward;

    EditText hour, min, sec;

    String Hour, Min, Sec;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        stopwatch = findViewById(R.id.forward);
        backward = findViewById(R.id.back);

        hour = findViewById(R.id.hour);
        min = findViewById(R.id.min);
        sec = findViewById(R.id.sec);

        hour.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {

                if(KeyEvent.ACTION_DOWN == i && keyEvent.getAction() == KeyEvent.KEYCODE_ENTER) {

                    Hour = hour.getText().toString().trim();

                    return true;

                }

                return false;
            }
        });

        min.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {

                if(KeyEvent.ACTION_DOWN == i && keyEvent.getAction() == KeyEvent.KEYCODE_ENTER) {

                    Min = min.getText().toString().trim();

                    return true;

                }

                return false;
            }
        });

        sec.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {

                if(KeyEvent.ACTION_DOWN == i && keyEvent.getAction() == KeyEvent.KEYCODE_ENTER) {

                    Sec = sec.getText().toString().trim();

                    return true;

                }

                return false;
            }
        });

        stopwatch.setOnClickListener(this);
        backward.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        if(view.getId() == stopwatch.getId()) {

            Intent intent = new Intent(getApplicationContext(), Stop.class);

            startActivity(intent);

        } else if(view.getId() == backward.getId()) {


        }

    }
}