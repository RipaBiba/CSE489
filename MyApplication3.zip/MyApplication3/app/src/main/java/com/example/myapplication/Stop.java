package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.net.URISyntaxException;

public class Stop extends AppCompatActivity implements View.OnClickListener {

    Button start, stop, pause;

    TextView hour, min, sec;

    String MIN, SEC, HOUR;

    public static Handler sHandler;
    private final int playPause = 0;
    private final int reset = 1;
    private int secs = 0;
    private int mins = 0;
    private int millis = 0;
    private long currentTime = 0L;
    private boolean isBound = false;
    private MyIntentService myService;
    private Intent intent;

    @SuppressLint("HandlerLeak")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stop);

        hour = findViewById(R.id.hour);
        min = findViewById(R.id.min);
        sec = findViewById(R.id.sec);

        start = findViewById(R.id.start);
        stop = findViewById(R.id.stop);
        pause = findViewById(R.id.pause);

        hour.setText("00");
        min.setText("00");
        sec.setText("00");

        HOUR = hour.getText().toString().trim();
        MIN = min.getText().toString().trim();
        SEC = sec.getText().toString().trim();

        hour.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {

                if(KeyEvent.ACTION_DOWN == i && keyEvent.getAction() == KeyEvent.KEYCODE_ENTER) {

                    HOUR = hour.getText().toString().trim();

                    return true;

                }

                return false;
            }
        });

        min.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {

                if(KeyEvent.ACTION_DOWN == i && keyEvent.getAction() == KeyEvent.KEYCODE_ENTER) {

                    MIN = min.getText().toString().trim();

                    return true;

                }

                return false;
            }
        });

        sec.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {

                if(KeyEvent.ACTION_DOWN == i && keyEvent.getAction() == KeyEvent.KEYCODE_ENTER) {

                    SEC = sec.getText().toString().trim();

                    return true;

                }

                return false;
            }
        });

        start.setOnClickListener(this);
        stop.setOnClickListener(this);
        pause.setOnClickListener(this);

        //BroadcastReceiver broadcastReceiver = new BroadcastReceiver();


        /*IntentFilter filter = new IntentFilter();
        filter.addAction("Send_Message");
        registerReceiver(broadcastReceiver, filter);*/

        BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                String time = intent.getStringExtra("time");

                currentTime = Long.parseLong(time);

                secs = (int) (currentTime / 1000);
                mins = secs / 60;
                secs = secs % 60;
                millis = (int) (currentTime % 1000);
                setTime();

                System.out.println("I am here " + time);

            }
        };

    }

    /*public void playPause() {

        myService.startStop();

    }*/
    @SuppressLint("NonConstantResourceId")

    /*public void reset() {

        myService.reset();
        mins = 0;
        secs = 0;
        millis = 0;
        setTime();

    }*/

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopService(intent);
        finishAffinity();

    }

    /*@Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter();
        filter.addAction("Send_Message");
        registerReceiver(broadcastReceiver, filter);
    }*/

    /*private ServiceConnection myConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {

            MyIntentService.LocalBinder binder = (MyIntentService.LocalBinder) service;
            myService = binder.getService();
            isBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
        }
    };*/

    public void setTime() {
        hour.setText("" + mins);
        min.setText(secs + "");
        sec.setText(millis + "");
    }

    @SuppressLint("HandlerLeak")
    @Override
    public void onClick(View view) {

        if(view.getId() == start.getId()) {

            /*intent = new Intent(getApplicationContext(), MyIntentService.class);

            Stop.sHandler = new Handler() {

                @Override
                public void handleMessage(Message timeMsg) {
                    super.handleMessage(timeMsg);

                    currentTime = Long.valueOf(timeMsg.obj.toString());

                    secs = (int) (currentTime / 1000);
                    mins = secs / 60;
                    secs = secs % 60;
                    millis = (int) (currentTime % 1000);
                    setTime();
                }
            };

            startService(intent);*/

            Toast.makeText(getApplicationContext(), "I am here", Toast.LENGTH_LONG).show();

            intent = new Intent(getApplicationContext(), MyIntentService.class);

            getApplicationContext().startService(intent);

        } else if(view.getId() == stop.getId()) {

            stopService(intent);

        } else if(view.getId() == pause.getId()) {


        }

    }

}