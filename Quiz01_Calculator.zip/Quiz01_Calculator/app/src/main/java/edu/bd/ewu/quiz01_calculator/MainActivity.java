package edu.bd.ewu.quiz01_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

public class MainActivity extends AppCompatActivity {

    Button delete, clear, divide, multiply, minus,
            plus, dot, equal, seven, eight,
            nine, four, five, six, one, two, three, zero;
    TextView result, written;
    String data;
    float Result1, Result2;
    boolean Add, Sub, Mul, Div;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        delete = findViewById(R.id.delete);
        clear = findViewById(R.id.clear);
        divide = findViewById(R.id.divide);
        multiply = findViewById(R.id.multiply);
        minus = findViewById(R.id.minus);
        plus = findViewById(R.id.plus);
        dot = findViewById(R.id.dot);
        equal = findViewById(R.id.equal);

        seven = findViewById(R.id.seven);
        eight = findViewById(R.id.eight);
        nine = findViewById(R.id.nine);
        four = findViewById(R.id.four);
        five = findViewById(R.id.five);
        six = findViewById(R.id.six);
        one = findViewById(R.id.one);
        two = findViewById(R.id.two);
        three = findViewById(R.id.three);
        zero = findViewById(R.id.zero);

        result = findViewById(R.id.result);
        written = findViewById(R.id.written);

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                result.setText(" ");
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                written.setText(" ");
                result.setText(" ");
            }
        });

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();
                result.setText(data + "+");
            }
        });

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();
                result.setText(data + "-");
            }
        });

        multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();
                //result.setText(data + "×");
                result.setText(data + "*");
            }
        });

        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();
                //result.setText(data + "÷");
                result.setText(data + "/");

                /*if (result == null) {
                    result.setText("0");
                } else {
                    Result1 = Float.parseFloat(result.getText() + "");
                    Div = true;
                    result.setText("");
                }*/
            }
        });

        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();

                //data.replaceAll("×", "*");
                //data.replaceAll("÷", "/");

                Context rhino = Context.enter();
                rhino.setOptimizationLevel(-1);

                String FinalResult="";
                Scriptable scriptable = rhino.initStandardObjects();
                FinalResult = rhino.evaluateString(scriptable, data, "Javascript", 1, null).toString();

                written.setText(FinalResult);
            }
        });

        dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();
                result.setText(data + ".");            }
        });

        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();
                result.setText(data + "1");            }
        });

        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();
                result.setText(data + "2");            }
        });

        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();
                result.setText(data + "3");            }
        });

        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();
                result.setText(data + "4");            }
        });

        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();
                result.setText(data + "5");            }
        });

        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();
                result.setText(data + "6");
            }
        });

        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();
                result.setText(data + "7");            }
        });

        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();
                result.setText(data + "8");            }
        });

        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();
                result.setText(data + "9");
            }
        });

        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = result.getText().toString();
                result.setText(data + "0");
            }
        });

    }
}