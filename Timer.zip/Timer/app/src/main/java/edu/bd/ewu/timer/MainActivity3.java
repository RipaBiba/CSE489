package edu.bd.ewu.timer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity3 extends AppCompatActivity {
    private CountDownTimer CountDownTimer;
    private boolean TimerRunning;
    private long TimeLeftInMillis;
    private long StartTimeInMillis;
    private long EndTime;

    public TextView timer_count;
    public EditText edit_timer;
    public Button start_count, pause_count, reset_count,stop_count, set_count, back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        timer_count = findViewById(R.id.timer_count);
        edit_timer = findViewById(R.id.edit_timer);

        start_count = findViewById(R.id.start_count);
        pause_count = findViewById(R.id.pause_count);
        reset_count = findViewById(R.id.reset_count);
        stop_count = findViewById(R.id.stop_count);
        set_count = findViewById(R.id.set_count);
        back = findViewById(R.id.back);

        start_count.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startTimer();
            }
        });

        pause_count.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TimerRunning){
                    pauseTimer();
                }
            }
        });

        reset_count.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetTimer();
            }
        });

        stop_count.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopTimer();
            }
        });

        set_count.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String input = edit_timer.getText().toString();
                if(input.length() == 0){
                    Toast.makeText(MainActivity3.this, "Fields Can't be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                long millisInput = Long.parseLong(input) * 60000;
                if(millisInput == 0){
                    Toast.makeText(MainActivity3.this, "Please Enter Positive Number", Toast.LENGTH_SHORT).show();
                    return;
                }

                setTime(millisInput);
                edit_timer.setText("");
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void setTime(long milliseconds){
        StartTimeInMillis = milliseconds;
        resetTimer();
    }

    private void startTimer(){
        EndTime = System.currentTimeMillis() + TimeLeftInMillis;

        CountDownTimer = new CountDownTimer(TimeLeftInMillis, 1000) {
            @Override
            public void onTick(long l) {
                TimeLeftInMillis = l;
                updateCountDownText();
            }

            @Override
            public void onFinish() {
                TimerRunning = false;
                updateInterfaces();
            }
        }.start();
        TimerRunning = true;
        updateInterfaces();
    }

    private void pauseTimer(){
        CountDownTimer.cancel();
        TimerRunning = false;
        updateInterfaces();
    }

    private void resetTimer(){
        TimeLeftInMillis = StartTimeInMillis;
        updateCountDownText();
        updateInterfaces();
    }

    private void stopTimer(){
        StartTimeInMillis = 0;
        TimeLeftInMillis = StartTimeInMillis;
        TimerRunning = false;
        CountDownTimer.cancel();
        timer_count.setText("00:00:00");
        updateInterfaces();
    }

    private void updateCountDownText(){
        int hours = (int) (TimeLeftInMillis / (1000 * 60 * 60)) % 24;
        int minutes = (int) (TimeLeftInMillis / (1000 * 60)) % 60;
        int seconds = (int) (TimeLeftInMillis / 1000) % 60;

        String timer_counter = String.format(Locale.getDefault(),"%02d:%02d:%2d", hours, minutes, seconds);

        timer_count.setText(timer_counter);
    }

    private void updateInterfaces(){
        if(TimerRunning){
            edit_timer.setVisibility(View.INVISIBLE);
            set_count.setVisibility(View.INVISIBLE);
            reset_count.setVisibility(View.INVISIBLE);
        } else{
            edit_timer.setVisibility(View.VISIBLE);
            set_count.setVisibility(View.VISIBLE);
            if(TimeLeftInMillis < StartTimeInMillis){
                reset_count.setVisibility(View.VISIBLE);
            } else{
                reset_count.setVisibility(View.INVISIBLE);
            }
        }
    }

    /*@Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putLong("millisLeft", TimeLeftInMillis);
        outState.putBoolean("timerRunning", TimerRunning);
        outState.putLong("endTime", EndTime);
    }*/

    /*@Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        TimeLeftInMillis = savedInstanceState.getLong("millisLeft");
        TimerRunning = savedInstanceState.getBoolean("timerRunning");
        updateCountDownText();
        updateInterfaces();

        if(TimerRunning){
            EndTime = savedInstanceState.getLong("endTime");
            TimeLeftInMillis = EndTime - System.currentTimeMillis();
            startTimer();
        }
    }*/

    @Override
    protected void onStart() {
        super.onStart();

        SharedPreferences preferences = getSharedPreferences("preferences", MODE_PRIVATE);

        StartTimeInMillis = preferences.getLong("StartTimeInMillis", 6000000);
        TimerRunning = preferences.getBoolean("timerRunning", false);
        TimeLeftInMillis = preferences.getLong("millsLeft", StartTimeInMillis);

        updateCountDownText();
        updateInterfaces();

        if(TimerRunning){
            EndTime = preferences.getLong("endTime", 0);
            TimeLeftInMillis = EndTime - System.currentTimeMillis();

            if(TimeLeftInMillis < 0){
                TimeLeftInMillis = 0;
                TimerRunning = false;
                updateCountDownText();
                updateInterfaces();
            } else{
                startTimer();
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        SharedPreferences preferences = getSharedPreferences("preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();

        editor.putLong("StartTimeInMillis", StartTimeInMillis);
        editor.putLong("millisLeft", TimeLeftInMillis);
        editor.putBoolean("timerRunning", TimerRunning);
        editor.putLong("endTime", EndTime);

        editor.apply();

        if(CountDownTimer != null){
            CountDownTimer.cancel();
        }
    }
}