package edu.bd.ewu.timer;

import android.app.Service;
import android.os.Handler;
import android.content.Intent;
import android.os.SystemClock;
import android.os.IBinder;

public class MyService extends Service {

    private Intent intent;
    private final static String TAG = "MyService";
    public static final String BROADCAST_ACTION = "edu.bd.ewu.timer";

    private Handler handler = new Handler();
    private long initial_time;
    long timeInMilliseconds = 0L;

    @Override
    public void onCreate() {
        super.onCreate();
        initial_time = SystemClock.uptimeMillis();
        intent = new Intent(BROADCAST_ACTION);
        handler.removeCallbacks(startTimer);
        handler.postDelayed(startTimer, 1000); // 1 second
    }

    private Runnable startTimer = new Runnable() {
        public void run() {
            updateStopWatch();
            handler.postDelayed(this, 1000); // 1 seconds
        }
    };

    private void updateStopWatch() {

        timeInMilliseconds = SystemClock.uptimeMillis() - initial_time;

        int timer = (int) timeInMilliseconds / 1000;
        intent.putExtra("time", timer);
        sendBroadcast(intent);

    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(startTimer);
    }

    public MyService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        //throw new UnsupportedOperationException("Not yet implemented");
        return null;
    }
}